CREATE USER guest
WITH PASSWORD 'guest';

CREATE DATABASE postgres
    WITH OWNER guest
    TEMPLATE = 'template0'
    ENCODING = 'utf-8'
    LC_COLLATE = 'C.UTF-8'
    LC_CTYPE = 'C.UTF-8';